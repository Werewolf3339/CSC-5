/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 16, 2016, 8:54 AM
 * Purpose: calculate paycheck
 */

#include <iostream>

using namespace std;

int main() 
{
    //pay rate, hours worked, pay check
    float payrate, hrswrkd, paychck;
    float ovrtime = 40; // where overtime begins
    //input values
    cout << "Input pay rate in dollars per hour" << endl;
    cin >> payrate;
    cout << "Input hours worked" << endl;
    cin >> hrswrkd;
    
    //map the inputs to the outputs
    if (hrswrkd <= ovrtime) paychck = hrswrkd * payrate;
    if (hrswrkd > ovrtime) paychck = hrswrkd * payrate + (hrswrkd - ovrtime) * payrate;
    if (hrswrkd < 0 || hrswrkd > 98) paychck = 0;
    
    //output the results
    cout << "Your paycheck is $" << paychck << endl;
    cout << "You worked " << hrswrkd << " hours this week" << endl;
    cout << "Your hourly pay rate is $" << payrate << endl;
    return 0;
}