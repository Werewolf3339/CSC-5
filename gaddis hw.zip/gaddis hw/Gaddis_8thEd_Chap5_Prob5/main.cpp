/* 
 * File:   main.cpp
 * Author: Brandon Fins 
 * Created on April 4, 2016, 9:54 AM
 * Purpose: 
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    float fee = 2500, inc = 1.04;
    //starting free is 2500, increases 4% per year
    int year = 1; // what year it is
    
    //calculate the increase for 6 years
    for (fee=2500; year<=6; year++) {
        fee=fee*inc;
        cout<<"The fee for year "<<year<<" is $"<<fee<<endl;
    }
    
    return 0;
}

