/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 4, 2016, 9:46 AM
 * Purpose: calculate calories burned on a treadmill
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    float burnrte = 3.6, burned; 
    //number of calories burned per minute, numbers of total calories burned
    int mins = 0; //how many minutes on the treadmill its been
    
    //do the calculation and output the results for 5 min increments
    for (burnrte=3.6; mins<=30; mins++) {
        burned=burnrte*mins;
        mins+=4;
        cout<<"You will burn "<<burned<<" for "<<mins<<" minutes of work."<<endl;
    }
    
    
    return 0;
}

