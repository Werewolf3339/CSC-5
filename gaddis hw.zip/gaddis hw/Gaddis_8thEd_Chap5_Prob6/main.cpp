/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 4, 2016, 10:02 AM
 * Purpose: calculate how far a vehicle has traveled
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    int speed, distanc, donetim, hours, error=0;
    //speed of the vehicle, how far its gone, how long its traveled, 
    //and placeholder, and error message
    
    //get the inputs
    cout<<"What is the speed of the vehicle?" 
            " Enter a positive whole number."<<endl;
    cin>>speed;
    cout<<"How long has it been traveling?"
            " Enter a whole number no less than 1."<<endl;
    cin>>donetim;
    
    //validate the input
    if (speed<0){
        error++;
        cout<<"Enter a positive number next time."<<endl;
    }
        
    if (donetim<1){
        error++;
        cout<<"Enter a number 1 or greater next time."<<endl;
    }
        
    //calculate the answer
    if (error==0){
        for (hours=1;hours<=donetim;hours++) {
            distanc=speed*hours;
            cout<<"During hour "<<hours<<" you will have traveled a total of "
                    <<distanc<<" miles, assuming you entered miles per hour."<<endl;
        }
    }
        return 0;
}

