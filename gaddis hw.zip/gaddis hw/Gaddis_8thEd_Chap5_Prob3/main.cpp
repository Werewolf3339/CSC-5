/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 4, 2016, 9:36 AM
 * Purpose: calculate ocean levels rising
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    float oclvl = 0, change = 1.5; // ocean level, how much it changes per year
    int year = 0; //number of years
    
    //calculate the rise
    for (change = 1.5; year <= 25; year++) {
        oclvl+=change;
        cout << "The ocean level for year "<<year<<" is "<<oclvl<<" mm."<<endl;
    }
   return 0;
}

