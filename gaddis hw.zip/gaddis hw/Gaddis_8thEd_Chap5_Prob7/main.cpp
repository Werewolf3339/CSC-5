/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 4, 2016, 10:21 AM
 * Purpose: calculate salary for exponential pennies
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main() 
{
    //declare variables
    float today, total;//todays wages, total wages
    int error = 0, numday, count; //for input validation and counting days
    
    //get the input
    cout<<"How many days were worked? Enter a positive integer."<<endl;
    cin>>numday;
    
    //input validation
    if (numday<0){
        error++;
        cout<<"Enter a positive number next time"<<endl;
    }
    
    cout<<fixed<<showpoint<<setprecision(2);
    
    //do the calculations
    if (error==0){
        for (count=1;count<=numday;count++){
            today=0.01*pow(2, count);
            total=total+today;
            cout<<"Day "<<count<<"'s wages were $"<<today
                <<". So far total wages total $"<<total<<"."<<endl;
        }
    }
    
    return 0;
}

