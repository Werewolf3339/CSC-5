/* 
 * File:   main.cpp
 * Author: Brandon Fins
 *Created on February 29, 2016, 10:06 
 * Purpose: Treadmill Readout Conversion
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

// Global Constraints
unsigned char CNVHRMN=60; //Conversion from hours to minutes
unsigned char CNVMNSC=60;//Conversion from minutes to seconds
int main(int argc, char** argv) {
    //declare variables
    float mph;//miles per hour
    float fmin;//pace minutes float
    int imin;//pace minutes integers
    float fsec;//pace residual seconds float
    int isec;//pace residual seconds integer
    
    //Prompt for the input mph
    cout<<"Input for the mile per hour pace (dd.dd)"<<endl;
    cin>>mph;
    
    //calculate the pace
    
    fmin=CNVHRMN/mph;//floating pace in minutes 
    imin=static_cast<int>(fmin);
    fsec=(fmin-imin)* CNVMNSC;//floating pace in seconds
    isec=static_cast<int>(fsec);
    
    //Output the results
    
    cout<<"The pace in mph = "<<endl;
    cout<<"The conversion is "<<imin<<" (minutes) "
            <<fsec<<" (seconds) per mile"<<endl;
    
    
    //Exit Stage right
    

    return 0;
}

