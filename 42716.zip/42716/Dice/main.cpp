/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 27, 2016, 8:08 AM
 * Purpose: play craps
 */

#include <cstdlib>
#include <iostream>
#include <ctime>
#include <fstream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {
    //set the random number seed for variability
    srand(static_cast<unsigned int>(time(0)));
    ofstream out;
    ifstream in;
    
    //declare variables
    unsigned int nthrows=0, maxthrw=0;
    unsigned short ngames=36000;
    unsigned short win=0, loss=0;
    
    //read from a file the number of games
    in.open ("incraps.dat");
    in>>ngames;
    
    //throw the dice
    for (unsigned short game=1; game<=ngames; game++){
        //randomly generate the throw and the sum
        unsigned short die1=rand()%6+1;
        unsigned short die2=rand()%6+1;
        unsigned short sumdie=die1+die2;
        unsigned short cntthrw=1;
        nthrows++;
        if (sumdie==7||sumdie==1)win++;
        else if (sumdie==2||sumdie==3||sumdie==12)loss++;
        else{
            bool thrwagn=true;
            do{
                unsigned short die1=rand()%6+1;
                unsigned short die2=rand()%6+1;
                unsigned short sumdie2=die1+die2;
                nthrows++;
                cntthrw++;
                if (maxthrw<cntthrw)maxthrw=cntthrw;
                if (sumdie==sumdie2){
                    win++;
                    thrwagn=false;}
                else if (sumdie2==7){
                    loss++;
                    thrwagn=false;}
                
            }while(thrwagn==true);
        }
    }
    cout<<"The total games played: "<<ngames<<endl;
    cout<<"The number of wins: "<<win<<endl;
    cout<<"The number of losses: "<<loss<<endl;
    cout<<"Wins: "<<(100.0f*win/ngames)<<endl;
    cout<<"Losses: "<<(100.0f*loss/ngames)<<endl;
    cout<<"The total games played: "<<(win+loss)<<endl;
    cout<<"The average throws per game: "<<(1.0f*nthrows/ngames)<<endl;
    cout<<"The maximum number of throws in one game: "<<maxthrw<<endl;
    
    //output to a file
    out.open("Craps.dat",ios::app);
    out<<fixed<<setprecision(2)<<showpoint;
    out<<"The total games played: "<<ngames<<endl;
    out<<"The number of wins: "<<win<<endl;
    out<<"The number of losses: "<<loss<<endl;
    out<<"Wins: "<<(100.0f*win/ngames)<<endl;
    out<<"Losses: "<<(100.0f*loss/ngames)<<endl;
    out<<"The total games played: "<<(win+loss)<<endl;
    out<<"The average throws per game: "<<(1.0f*nthrows/ngames)<<endl;
    out<<"The maximum number of throws in one game: "<<maxthrw<<endl;
    
    
    out.close();
    in.close();
    return 0;
}

