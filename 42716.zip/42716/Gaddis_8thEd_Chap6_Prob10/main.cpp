/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 27, 2016, 10:23 AM
 * Purpose: determine future value, given present value and interest
 */

#include <cstdlib>
#include <cmath>
#include <iostream>

using namespace std;

float futurevalue(int, float, int);


int main() {
    //declare variables
    int present, future, months;
    float rate;
    cout<<"What is the present value?"<<endl;
    cin>>present;
    cout<<"What is the interest rate? Enter as a decimal."<<endl;
    cin>>rate;
    cout<<"How many months will it get to accumulate?"<<endl;
    cin>>months;
    
    future=futurevalue(present, rate, months);
    cout<<"The amount you will have in the future is $"<<future<<endl;
    
    return 0;
}

float futurevalue(int present, float rate, int months){
    float future;
    future=(present*(pow((1+rate),months)));
    return future;
}
