/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 27, 2016, 10:12 AM
 * Purpose: simulate a coin toss
 */

#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int cointoss (int);

int main() {
    //declare variables
    int heads, times;
    srand(static_cast<unsigned int>(time(0)));
    
    cout<<"How many coin tosses should be simulated?"<<endl;
    cin>>times;
    
    heads=cointoss(times);
    
    cout<<"Number of heads: "<<heads<<endl;
    cout<<"Number of tails: "<<(times-heads)<<endl;
    cout<<"Total tosses: "<<times<<endl;
    
    return 0;
}

int cointoss(int times){
    int heads;
    for (int count=0;count<times;count++){
        if ((rand()%2+1)==1){
            heads++;
        }
    }
    return heads;
}
