/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on April 27, 2016, 9:57 AM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    fstream infile("koala.dat", ios::in);
    
    while(!infile.eof()) {
        string myStr;
        getline(infile, myStr);
        
        cout << myStr << endl;
    }
    
    system("cls");
    return 0;
}

