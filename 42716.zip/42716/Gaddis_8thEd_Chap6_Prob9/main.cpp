/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 27, 2016, 10:23 AM
 * Purpose: determine present value, given a future value desired
 */

#include <cstdlib>
#include <cmath>
#include <iostream>

using namespace std;

float futurevalue(int, float, int);


int main() {
    //declare variables
    int present, future, years;
    float rate;
    cout<<"What is the desired future value?"<<endl;
    cin>>future;
    cout<<"What is the interest rate? Enter as a decimal."<<endl;
    cin>>rate;
    cout<<"How many years will it get to accumulate?"<<endl;
    cin>>years;
    
    present=futurevalue(future, rate, years);
    cout<<"The amount you need to have at present is $"<<present<<endl;
    
    return 0;
}

float futurevalue(int future, float rate, int years){
    float present;
    present=(future/(pow((1+rate),years)));
    return present;
}
