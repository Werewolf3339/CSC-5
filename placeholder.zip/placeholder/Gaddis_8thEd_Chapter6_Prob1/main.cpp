/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 25, 2016, 9:32 AM
 * Purpose: display wholesale cost and markup of an item
 */

#include <iostream>
#include <iomanip>

using namespace std;

//function prototypes
float calculateRetail(float,float);

int main() {
    //declare variables
    float wholesl, mrkup;
    //wholesale price and markup percentage
    cout<<"What is the wholesale cost of the item?"<<endl;
    cin>>wholesl;
    cout<<"What is the markup %?"<<endl;
    cin>>mrkup;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"The price of the item will be $"<<calculateRetail(wholesl, mrkup);
    
    return 0;
}

float calculateRetail(float wholesl,float mrkup){
    return (wholesl+wholesl*(mrkup/100));
    }
