/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 25, 2016, 9:32 AM
 * Purpose: determine which sales division sold the most
 */

#include <iostream>
#include <iomanip>

using namespace std;

//function prototypes
float getsales(string);
void findhighest(float, float, float, float);

int main() {
    //declare variables
    float nwsales, swsales, nesales, sesales;
    string nw="Northwest", sw="Southwest", ne="Northeast", se="Southeast";
    nwsales=getsales(nw);
    swsales=getsales(sw);
    nesales=getsales(ne);
    sesales=getsales(se);
    findhighest(nwsales, swsales, nesales, sesales);
    return(0);
}
float getsales(string name){
    float sales;
    do{
    cout<<"What was the sales total for the "<<name<<" division?"<<endl;
    cin>>sales;}
    while (sales<0);
    return sales;
}
void findhighest(float num1, float num2, float num3, float num4){
    if (num1>num2&&num1>num3&&num1>num4){
        cout<<"Northwest division won with $"<<num1<<" in sales.";}
    if (num2>num1&&num2>num3&&num2>num4){
        cout<<"Southwest division won with $"<<num2<<" in sales.";}
    if (num3>num2&&num3>num1&&num1>num4){
        cout<<"Northeast division won with $"<<num3<<" in sales.";}
    if (num4>num1&&num4>num2&&num4>num3){
        cout<<"Southeast division won with $"<<num4<<" in sales.";}
    }