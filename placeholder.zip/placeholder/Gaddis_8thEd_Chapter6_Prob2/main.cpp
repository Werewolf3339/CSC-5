/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 25, 2016, 9:32 AM
 * Purpose: display wholesale cost and markup of an item
 */

#include <iostream>
#include <iomanip>

using namespace std;

//function prototypes
float getlength();
float getwidth();
float getarea (float, float);
void displaydata(float);

int main() {
    //declare variables
    float length, width, area;
    length=getlength();
    width=getwidth();
    area=getarea(length, width);
    displaydata(area);
    
    return 0;
}
float getlength(){
    float length;
    cout<<"What is the length of the rectangle?"<<endl;
    cin>>length;
    return length;           
}
float getwidth(){
    float width;
    cout<<"What is the width of the rectangle?"<<endl;
    cin>>width;
    return width;           
}
float getarea (float l, float w){
    return (l*w);
}
void displaydata(float a){
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"The area of the rectangle is "<<a<<endl;
}
