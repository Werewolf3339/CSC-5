/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 14, 2016, 9:39 AM
 * Purpose: Boolean Table
 */
#include <iostream>
using namespace std;
int main() 
{
    bool x1 = true;
    bool x2 = true;
    bool x3 = false;
    bool x4 = false;
    bool y1 = true;
    bool y2 = false;
    bool y3 = true;
    bool y4 = false;
    
    int a = 2;
    int b = 3;
    
    cout << "X - Y - !X - !Y - X&&Y - X||Y - X^Y - X^Y^Y - X^Y^X - !(X&&Y) - !X||!Y - !(X||Y) - !X&&!Y" << endl;
    cout << (x1?'T':'F') << " - " << (y1?'T':'F') << " -  " << (!x1?'T':'F') << " -  " << (!y1?'T':'F') << " -    " << (x1&&y1?'T':'F') << " -    " << (x1||y1?'T':'F') << " -   " << (x1^y1?'T':'F') << " -     " << (x1^y1^y1?'T':'F') << " -     " << (x1^y1^x1?'T':'F') << " -       "<< (!(x1&&y1)?'T':'F') << " -      " << (!x1||!y1?'T':'F') << " -       " << (!(x1||y1)?'T':'F') << " -      " << (!x1&&!y1?'T':'F') << endl;
    cout << (x2?'T':'F') << " - " << (y2?'T':'F') << " -  " << (!x2?'T':'F') << " -  " << (!y2?'T':'F') << " -    " << (x2&&y2?'T':'F') << " -    " << (x2||y2?'T':'F') << " -   " << (x2^y2?'T':'F') << " -     " << (x2^y2^y2?'T':'F') << " -     " << (x2^y2^x2?'T':'F') << " -       "<< (!(x2&&y2)?'T':'F') << " -      " << (!x2||!y2?'T':'F') << " -       " << (!(x2||y2)?'T':'F') << " -      " << (!x2&&!y2?'T':'F') << endl;
    cout << (x3?'T':'F') << " - " << (y3?'T':'F') << " -  " << (!x3?'T':'F') << " -  " << (!y3?'T':'F') << " -    " << (x3&&y3?'T':'F') << " -    " << (x3||y3?'T':'F') << " -   " << (x3^y3?'T':'F') << " -     " << (x3^y3^y3?'T':'F') << " -     " << (x3^y3^x3?'T':'F') << " -       "<< (!(x3&&y3)?'T':'F') << " -      " << (!x3||!y3?'T':'F') << " -       " << (!(x3||y3)?'T':'F') << " -      " << (!x3&&!y3?'T':'F') << endl;
    cout << (x4?'T':'F') << " - " << (y4?'T':'F') << " -  " << (!x4?'T':'F') << " -  " << (!y4?'T':'F') << " -    " << (x4&&y4?'T':'F') << " -    " << (x4||y4?'T':'F') << " -   " << (x4^y4?'T':'F') << " -     " << (x4^y4^y4?'T':'F') << " -     " << (x4^y4^x4?'T':'F') << " -       "<< (!(x4&&y4)?'T':'F') << " -      " << (!x4||!y4?'T':'F') << " -       " << (!(x4||y4)?'T':'F') << " -      " << (!x4&&!y4?'T':'F') << endl;
    
    cout << "A is " << a << endl;
    cout << "B is " << b << endl;
    /*
     int temp = a;
     a = b;
     b = temp;
     */
    
    
    a = a^b;
    b = a^b;
    a = a^b;
   
    //swap (a, b);
    
    // b = (a^b)^b;
    // a = (a^b)^a;
    
    cout << "After being swapped, A is " << a << endl;
    cout << "After being swapped, B is " << b << endl;
    return 0;
}

