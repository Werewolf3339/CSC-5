/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 4, 2016, 7:45 AM
 * Purpose : sum 1-10 using a for loop
 */

#include <iostream>

using namespace std;

int main() 
{
    int sum = 0, total = 0;
    for (total=0; sum<11; sum++){
        total+=sum; }
        
    cout << total;
    return 0;
}

