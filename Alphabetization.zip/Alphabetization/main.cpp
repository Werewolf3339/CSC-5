/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 16, 2016, 10:06 AM
 * purpose: alphabetize names
 */

#include <iostream>
#include <cstring>

using namespace std;

int main() 
{
    //declare variables
    const int SIZE = 20;
    char first[20], second[20], third[20];
    //get the names
    
    cout << "Enter the first name:" << endl;
    cin.getline (first, 20);
    cout << "Enter the second name:" << endl;
    cin.getline (second, 20);
    cout << "Enter the third name:" << endl;
    cin.getline (third, 20);
    
    //compare them with strcmp
    if (strcmp (first, third) > 0)
        swap (first, third);
    if (strcmp (first, second) > 0)
        swap (first, second);
    if (strcmp (second, third) >0)
        swap (second, third);
    
    //output them alphabetically
    cout << "Here are the names sorted alphabetically:" << endl;
    cout << first << endl;
    cout << second << endl;
    cout << third << endl;
    
    return 0;
}


