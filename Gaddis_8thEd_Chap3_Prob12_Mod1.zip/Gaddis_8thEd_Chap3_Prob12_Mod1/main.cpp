/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 9, 2016, 10:09 AM
 * Purpose: the other problem didn't work, so now we are doing this one
 */

#include <iostream>
#include <cmath>

using namespace std;
int main() 
{
    float f1 (32), f2 (212), c1 (0), c2 (100), f, firstc, secondc;
    //freezing and boiling points of water in fahrenheit and then celsius, and the input fahrenheit degrees to be converted
    cout << "What are the degrees in Fahrenheit?" << endl; //get the input in degrees fahrenheit
    cin >> f;
    firstc = (f-32)*(5.0f/9); //linear scale
    secondc = c1+(c2-c1)*((f-f1)/(f2-f1)); //interpolation
    cout << "The linear scale gives " << firstc << " degrees Celsius" << endl;
    cout << "The interpolation gives " << secondc << " degrees Celsius" << endl;
    return 0;
}

