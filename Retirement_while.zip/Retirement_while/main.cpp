/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 30, 2016, 8:34 AM
 * Purpose: figure out retirement using a while loop
 */

#include <iostream>
#include <iomanip>

using namespace std;

int main() 
{
    //declare variables
    float salary = 60000; // desired yearly salary
    float percdep = 1e-1f; //10% to save each year
    float pv = 0; //preset value
    float irate = 0.05f; //interest rate
    float nyears = 0; // comparison of calculation to the rule of 72
    float fv = pv; // future value
    float yrlydep; // yearly deposit in $'s
    float savret; // savings to retire in $'s
    
    //calculate the approximate savings required to retire
    savret = salary/irate;
    yrlydep = salary*percdep;
    
    //output the initial conditions and setup the table
    cout << "Savings required to retire = $" << savret << endl;
    cout << "Yearly deposit/ minicipal bond purchase = $" << yrlydep << endl;
    cout << "Interest rate = " << irate*100 << "%" << endl;
    cout << "Years   future value" << endl;
    cout << fixed << setprecision(2) << showpoint;
    cout << setw(3) << nyears << setw(10) << " $" << fv << endl;
    
    //loop each year until the future value is 2x the presetn value
    nyears = 1;
    while (fv<savret) {
        fv*=(1+irate); // yearly interest
        fv+=yrlydep;
        cout << setw(3) << nyears << setw(10) << " $" << fv << endl;
        nyears++;
}
    
    
    return 0;
}

