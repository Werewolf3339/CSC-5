/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 30, 2016, 9:31 AM
 * Purpose: creating a menu to view problems 1-10
 */

#include <iostream>
#include <iomanip>

using namespace std;

int main() 

//execution begins here

{
    int key; // menu selection
    
    cout << "Enter a number, 1-10, in order to view that problem." << endl;
    cout << "Entering anything other than 1-10 will cause the menu to exit." << endl;
    cin >> key;

    switch (key) {
        case (1): //problem 1
            cout << "Problem 1." << endl;
            break;
        case (2): //problem 2
            cout << "Problem 2." << endl;
            break;
        case (3): //problem 3
            cout << "Problem 3." << endl;
            break;
        case (4): //problem 4
            cout << "Problem 4." << endl;
            break;
        case (5): //problem 5
            cout << "Problem 5." << endl;
            break;
        case (6): //problem 6
            cout << "Problem 6." << endl;
            break;
        case (7): //problem 7
            cout << "Problem 7." << endl;
            break;
        case (8): //problem 8
            cout << "Problem 8." << endl;
            break;
        case (9): //problem 9
            cout << "Problem 9." << endl;
            break;
        case (10): //problem 10
            cout << "Problem 10." << endl;
            break;
        default: //exit strategy
            cout << "Program will now exit." << endl;
        }
    //thats all folks
    return 0;
}

