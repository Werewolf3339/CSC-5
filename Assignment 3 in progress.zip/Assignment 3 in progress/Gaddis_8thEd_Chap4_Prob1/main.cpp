/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 28, 2016, 9:59 AM
 * Purpose: Given two numbers, figure out which one is larger using a conditional operator
 */

#include <iostream>

using namespace std;

int main () 
{
// declare vairables
    int one, two, three;
    
    //get the numbers
    cout << "What is the first number?" << endl;
    cin >> one;
    cout << "What is the second number?" << endl;
    cin >> two;
    
    //figure which one is larger
    three = (one>two)? (three = one) : (three = two);
    
    //output the larger one
    cout << "The larger number is " << three << endl; 
    
    
    return 0;
}

