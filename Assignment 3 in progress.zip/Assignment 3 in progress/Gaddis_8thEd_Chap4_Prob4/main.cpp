/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 28, 2016, 10:27 AM
 * Purpose: to determine which rectangle is larger, given 2 rectangles
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    int length1, length2, width1, width2, area1, area2;
    
    //get the info
    cout << "What is the length of rectangle 1?" << endl;
    cin >> length1;
    cout << "What is the width of rectangle 1?" << endl;
    cin >> width1;
    cout << "What is the length of rectangle 2?" << endl;
    cin >> length2;
    cout << "What is the width of rectangle 2?" << endl;
    cin >> width2;
    
    //figure out the areas
    area1 = length1 * width1;
    area2 = length2 * width2;
    
    //figure out which one is bigger and tell the user    
    if (area1>area2)
        cout << "Rectangle 1 is larger." << endl;
    if (area1<area2)
        cout << "Rectangle 2 is larger." << endl;
    if (area1==area2)
        cout << "Both rectangles have the same area" << endl;
    
    return 0;
}

