/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 28, 2016, 10:27 AM
 * Purpose: to figure out if a date is "magic"
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    int day, month, year;
    
    //get the input 
    cout << "Enter the day" << endl;
    cin >> day;
    cout << "Enter the month" << endl;
    cin >> month;
    cout << "Enter the year" << endl;
    cin >> year;
    
    //figure out if the date is "magic"
    if (year == month * day) 
        cout << "It's a magical date. Congratulations." << endl;
    else 
        cout << "It's a normal, boring day. Have fun." << endl;
    
    return 0;
}

