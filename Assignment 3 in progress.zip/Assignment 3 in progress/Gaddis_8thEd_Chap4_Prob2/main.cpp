/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 28, 2016, 10:10 AM
 * Purpose: convert numbers 1 through 10 into Roman Numerals
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    int num;
    
    //get input
    cout << "What number do you want to be converted into a Roman numeral?" << endl;
    cout << "Input a number between 1 and 10." << endl;
    cin >> num;
    
    //do the conversion
    switch (num) {
        case 1: cout << "The Roman numeral for 1 is I." << endl;
                break;
        case 2: cout << "The Roman numeral for 2 is II." << endl;
                break;
        case 3: cout << "The Roman numeral for 3 is III." << endl;
                break;
        case 4: cout << "The Roman numeral for 4 is IV." << endl;
                break;
        case 5: cout << "The Roman numeral for 5 is V." << endl;
                break;
        case 6: cout << "The Roman numeral for 6 is VI." << endl;
                break;
        case 7: cout << "The Roman numeral for 7 is VII." << endl;
                break;
        case 8: cout << "The Roman numeral for 8 is VIII." << endl;
                break;
        case 9: cout << "The Roman numeral for 9 is IX." << endl;
                break;
        case 10: cout << "The Roman numeral for 10 is X." << endl;
                break;
        default: cout << "Please select a number between 1 and 10." << endl;
    }
    return 0;
}

