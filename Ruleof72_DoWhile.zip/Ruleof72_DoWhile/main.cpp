/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 28, 2016, 8:04 AM
 * Purpose: demonstrate rule of 72 using a while loop
 */

#include <iostream>
#include <iomanip>

using namespace std;

int main() 
{
    float fv, pv, in, cp, ny;
    // future value, present value, interest rate, compounding periods, 
    // number of years in comparison to rule of 72
    
    //get the numbers
    cout << "What is the interest rate? Enter as a percentage." << endl;
    cin >> in;
    cout << "What is the present value?" << endl;
    cin >> pv;
    
    // convert interest rate to a decimal
    in = (in/100);
    
    //give future value a number
    fv = pv;
    cp = 0;
    //calculate the approximate numbers of years to double by rule of 72
    ny = (0.72f/in);
    
    //set up the table
    cout << "Present value is $" << pv << endl;
    cout << "Interest rate is " << in << "%" << endl;
    cout << "Years   Future value" << endl;
    cout << fixed << setprecision(2) << showpoint;
    cout << setw(3) << cp <<setw(10) << " $" << fv << endl;
    
    //loop each year until the future value is 2x the present value
    do { 
        fv *= (1 + in); // yearly interest rate calculation
        cp++; //increment the number of years
        cout << setw(3) << cp << setw(10) << " $" << fv << endl;
    } while (fv < 2*pv);
    
    //convert interest back to a whole number
    in = (in*100);
    
    //output the results
    cout << "You started with $" << pv << endl;
    cout << "At " << in << "% interest, you will end with $" << fv << endl;
    cout << "By the rule of 72, it will take " << ny << " years for your money to double" << endl;
    
    return 0;
}

