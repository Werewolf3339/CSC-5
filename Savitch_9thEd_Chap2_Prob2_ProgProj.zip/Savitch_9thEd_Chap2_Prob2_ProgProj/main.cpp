/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 9, 2016, 8:57 AM
 * Purpose: calculate backpay
 */

#include <iostream>
#include <iomanip>
using namespace std;
int main() 
{
    // calculating backpay owed
    float oldsal, oldmont, newmont, newsal, backpay, montowe, perinc, servfee; 
    // old annual salary, old monthly salary, new monthly salary
    // new annual salary, backpay owed, months owed, salary percentage increase
    // service fee for using this program
    // get the info
    cout << "What is your current annual salary?" << endl;
    cin >> oldsal;
    cout << "What is your pay raise? Write it as a percentage." << endl;
    cin >> perinc;
    cout << "How many months have you been owed your raise?" << endl;
    cin >> montowe;
    // calculate their new salary, etc
    perinc = perinc/100; // convert the percentage to a decimal
    oldmont = oldsal/12; //find out the old monthly salary
    newsal = oldmont*(1+perinc)*12; // figure out the new yearly salary
    newmont = newsal/12; // new monthly is easy
    backpay = ((newsal-oldsal)/12)*montowe; //backpay is just the difference divided by the months they were owed
    servfee = backpay*0.05; //calculate what they owe you
    //tell them what they want to know
    cout << fixed << showpoint << setprecision (2);
    cout << "Your old salary was $" << oldsal << " per year." << endl; //old salary
    cout << "You got a pay raise of " << (perinc*100) << "%." << endl; //their raise
    cout << "Your new salary is $" << newsal << " per year." << endl; // new salary
    cout << "You should have been getting $" << newmont << " per month instead of $" << oldmont << " for the past "
            << montowe << " months." << endl; //new monthly salary, followed by old monthly salary, and the amount of months.
    cout << "This means you are owed $" << backpay << " by your employer." << endl; // tell them what they're owed
    cout << "A service fee of $" << servfee << " will be charged to your account. Thank you." << endl; //get paid
    //all done
    return 0;
}

