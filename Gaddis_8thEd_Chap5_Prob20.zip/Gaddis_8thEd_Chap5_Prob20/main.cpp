/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 7, 2016, 10:49 AM
 * Purpose : Problem 20
 */

#include <iostream>
#include <cmath>
using namespace std;

//global constant is pi
int main()
{
    int d; //diameter of pizza
    int nos; //number of slices
    int area; //area of pizza
    const float PI = Atan(1.0) * 4;
    cout << "What is the diameter of the pizza, in inches?" << endl;
    cin >> d;
    area = PI * pow(d,2) / 4;
    
    return 0;
}

